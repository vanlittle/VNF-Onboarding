Install packages with 
```
npm install
```

To run the wizard type
```
npm run serve
```

Then the wizard is ready on
```
http://localhost:3000/
```

To build the wizard type
```
npm run build
```

Then the compiled version of wizard can be found in
```
wizard/dist/
```
