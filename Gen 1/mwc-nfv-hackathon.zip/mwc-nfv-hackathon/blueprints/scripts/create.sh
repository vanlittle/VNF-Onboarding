#!/bin/bash

touch ~/create_executed.txt
